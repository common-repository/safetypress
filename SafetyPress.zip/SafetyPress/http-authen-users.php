<div class="wrap">
	<div id="icon-options-general" class="icon32"></div><h2>HTTP Authentication</h2>
<div class="wrap" style="font-family: Verdana;">
<?php
if(isset($_POST['save_http'])){
?>
    <div id="message" class="updated fade"><p><strong>Save complete</strong></p></div>
<?php
	if ( !isset( $_POST['safetypress_checkhttp'] ) )
	{
		update_option('safetypress_checkhttp', '');
	}
	else
	{
		if ( $_POST['safetypress_checkhttp'] == 'yes' )
			update_option('safetypress_checkhttp', 'yes');
		else
			update_option('safetypress_checkhttp', 'no');
	}
	if(isset($_POST['username']) && get_option('safetypress_username')!=  $_POST['username']) 
		update_option('safetypress_username', trim(sanitize_user( $_POST['username'] )));
	if(isset($_POST['password']) && get_option('safetypress_password')!= $_POST['password'])  
		update_option('safetypress_password', trim( md5( $_POST['password'] ) ));
	
}
?>
<form method="POST" action="<?php echo admin_url('admin.php?page=private-users'); ?>">
	
	<?php
	//	Nonces
	wp_nonce_field('private-users');
	?>
	<h3>Add a Private User</h3>
	<div>
	<input type="checkbox" name="safetypress_checkhttp" value="yes" <?php if ( get_option('safetypress_checkhttp') == 'yes' ) { echo 'checked="checked"';} ?> /> Check this to enable HTTP Authentication.
	</div>
	<br />
<label>Username : <input type="text" name="username" value="<?php echo get_option('safetypress_username'); ?>" /> </label><br />
<label>Password : <input type="password" name="password" value="<?php echo get_option('safetypress_password'); ?>" /> </label>

<div class="clear"></div><br />
	
<input class='button-primary' type='submit' name='save_http' value='<?php _e('Save Changes'); ?>' id='submitbutton' />
 <br />

	<p>Adding your private user will only work if you have "Private Username/Password" selected for HTTP Authentication.</p>
	<p>Please read about HTTP Authentication on <a href="http://en.wikipedia.org/wiki/Basic_access_authentication">Basic access authentication Wiki</a>.</p>
	<p><strong>Please note a few things:</strong>
		<ul>
			<li>1. If you are ever locked out, you can just delete the plugin files via FTP and you will be able to login again.</li>
			<li>2. You cannot delete the current HTTP Authentication username you are using right now.</li>		
			<li>3. Private user HTTP Authentication will not work if you don't have a username added below.</li>
		</ul>
	</p> 
	</form>
</div>