<h2>Backup to Dropbox</h2>
<div id="message" class="updated fade">
	<p><strong>You must upgrade version to use this feature!</strong></p>
	<a href="<?php echo admin_url('admin.php?page=upgrade'); ?>">Upgrade Here!</a>
</div>

<script src="<?php echo $uri ?>/Backup/wp-backup-to-dropbox.js" type="text/javascript" language="javascript"></script>
<script type="text/javascript" language="javascript">
	jQuery(document).ready(function ($) {
		$('#frequency').change(function() {
			var len = $('#day option').size();
			if ($('#frequency').val() == 'daily') { 	
				$('#day').append($("<option></option>").attr("value", "").text('Everyday'));
				$('#day option:last').attr('selected', 'selected');
				$('#day').attr('disabled', 'disabled');
			} else if (len == 8) {
				$('#day').removeAttr('disabled');
				$('#day option:last').remove();
			}
		});
	});

</script>
<style type="text/css">
	.backup_error {
		margin-left: 10px;
		color: red;
	}

	.backup_ok {
		margin-left: 10px;
		color: green;
	}

	.backup_warning {
		margin-left: 10px;
		color: orange;
	}

	.history_box {
		max-height: 140px;
		overflow-y: scroll;
	}

	.message_box {
		font-weight: bold;
		color: green;
	}

	#file_tree {
		margin-left: 10px;
		width: 400px;
		max-height: 200px;
		overflow-y: scroll;
	}

	#toggle-all {
		margin-left: 348px;
	}

	.bump {
		margin: 10px 0 0 10px;
	}
</style>
	<div class="wrap">
	
	<form id="backup_to_dropbox_options" name="backup_to_dropbox_options"
		  action="admin.php?page=backup-to-dropbox" method="post">
	
	<h3>Backup Now</h3>
	<div id="progress">
		<?php
			echo '<p>' . 'No backup in schedule.' . '</p>';
		?>
	</div>
	<input type="submit" id="start_backup" name="start_backup" class="button-secondary" value="Start Backup">
	<br/><br/><br/>
	<h3>Schedule Backup</h3>
	
	<table class="form-table">
		<tbody>	
		<tr valign="top">
			<th scope="row">Server Time</th>
			<td><?php echo date('H:i'); ?></td>
		<tr valign="top">
			<th scope="row"><label for="frequency">Frequency</label></th>
			<td>
				<select id="frequency" name="frequency">
					<option value="daily" selected="selected">Daily</option>
					<option value="weekly" >Weekly</option>				
					<option value="monthly" >Monthly</option>			
					<option value="three_monthly">Every 3 Months</option>
					<option value="half_year" >Every 6 Months</option>
					<option value="yearly">Yearly</option>
				</select>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="time">Day</label></th>
			<td>
				<select id="day" name="day">
					<option value="Mon">Monday</option>
					<option value="Tue">Tuesday</option>
					<option value="Wed">Wednesday</option>
					<option value="Thu">Thursday</option>
					<option value="Fri">Friday</option>
					<option value="Sat">Saturday</option>
					<option value="Sun">Sunday</option>
				</select> 
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="time">Time</label></th>
			<td>				
				<select id="hour" name="hour">
					<option value="00" selected="selected">00
					</option>
					<option value="01">01
					</option>
					<option value="02">02
					</option>
					<option value="03">03
					</option>					
					<option value="04">04
					</option>
					<option value="05">05
					</option>
					<option value="06">06
					</option>
					<option value="07">07
					</option>
					<option value="08">08
					</option>
					<option value="09">09
					</option>
					<option value="10">10
					</option>
					<option value="11">11
					</option>
					<option value="12">12
					</option>
					<option value="13">13
					</option>
					<option value="14">14
					</option>
					<option value="15">15
					</option>
					<option value="16">16
					</option>
					<option value="17">17
					</option>
					<option value="18">18
					</option>
					<option value="19">19
					</option>
					<option value="20">20
					</option>
					<option value="21">21
					</option>
					<option value="22">22
					</option>
					<option value="23">23
					</option>
				</select> : 
				<select id="min" name="min">
					<option value="00" selected="selected">00
					</option>
					<option value="05">05
					</option>
					<option value="10">10
					</option>
					<option value="15">15
					</option>					
					<option value="20">20
					</option>
					<option value="25">25
					</option>
					<option value="30">30
					</option>
					<option value="35">35
					</option>
					<option value="40">40
					</option>
					<option value="45">45
					</option>
					<option value="50">50
					</option>
					<option value="55">55
					</option>					
				</select>
			</td>
		</tr>		
		</tbody>
	</table>
	<p class="submit">
		<input type="submit" id="save_changes" name="save_changes" class="button-primary" value="Update Schedule">
		<input type="submit" id="btnClear" name="btnClear" class="bump button-secondary" value="Clear Schedule">
	</p>
	<br/><br/><br/>
	<h3>Next Backup Time</h3>	
			<p style="margin-left: 10px;">No backups scheduled.</p>
	<br/><br/><br/>
	<h3>History</h3>
		<p style="margin-left: 10px;">No history</p>