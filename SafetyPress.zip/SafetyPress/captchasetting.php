<?php if (! defined('ABSPATH')) exit; ?>
<div class="wrap">
	<div id="icon-options-general" class="icon32"></div><h2>Captcha Setting</h2>
<div class="wrap" style="font-family: Verdana;">
<?php
if(isset($_POST['save_captcha_options'])){
?>
    <div id="message" class="updated fade"><p><strong><?php _e('Save complete.', 'wpcaptchadomain'); ?></strong></p></div>
<?php
	if(isset($_POST['publickey'])) 
		update_option('recaptcha_publickey', trim($_POST['publickey']));
	if(isset($_POST['privatekey'])) 
		update_option('recaptcha_privatekey', trim($_POST['privatekey']));
	if(isset($_POST['captcha_login'])) {
		if($_POST['captcha_login'] == 'yes')
			update_option('wpcaptcha_login', 'yes');
		else 
			update_option('wpcaptcha_login', 'no');
	}
	else{
		update_option('wpcaptcha_login', 'no');
	}
	if(isset($_POST['captcha_register'])) {
		if($_POST['captcha_register'] == 'yes')
			update_option('wpcaptcha_register', 'yes');
		else 
			update_option('wpcaptcha_register', 'no');
	}
	else{
		update_option('wpcaptcha_register', 'no');
	}
	if(isset($_POST['captcha_lost'])) {
		if($_POST['captcha_lost'] == 'yes')
			update_option('wpcaptcha_lost', 'yes');
		else 
			update_option('wpcaptcha_lost', 'no');
	}
	else{
		update_option('wpcaptcha_lost', 'no');
	}
	if(isset($_POST['captcha_comments'])) {
		if($_POST['captcha_comments'] == 'yes')
			update_option('wpcaptcha_comments', 'yes');
		else 
			update_option('wpcaptcha_comments', 'no');
	}
	else{
		update_option('wpcaptcha_comments', 'no');
	}	
}
	$public_key = get_option('recaptcha_publickey');
	$private_key = get_option('recaptcha_privatekey');
	$c_login = get_option('wpcaptcha_login');
	if($c_login == 'yes') $c_login_yes = 'checked="checked"';
	else $c_login_yes = '';
	$c_register = get_option('wpcaptcha_register');
	if($c_register == 'yes') $c_register_yes = 'checked="checked"';
	else $c_register_yes = '';
	$c_lost = get_option('wpcaptcha_lost');
	if($c_lost == 'yes') $c_lost_yes = 'checked="checked"';
	else $c_lost_yes = '';
	$c_comments = get_option('wpcaptcha_comments');
	if($c_comments == 'yes') $c_comments_yes = 'checked="checked"';
	else $c_comments_yes = '';
	$domain = "";
	$url = get_home_url();
	if(is_ssl()){
		$domain = str_replace("https://","",$url);
	}
	else{
		$domain = str_replace("http://","",$url);
	}
?>
	<form method="post" action="">
	<h3><?php _e('reCaptcha API', 'wpcaptchadomain');?></h3>
        <table>
			 <tr height="40">
				<td><?php _e('Get Keys', 'wpcaptchadomain'); ?></td>
				<td>
				   <p>
						<a href="<?php echo recaptcha_get_signup_url($domain,"wordpress");?>" title="<?php _e('Get your reCAPTCHA API Keys', 'wpcaptchadomain'); ?>" target="_blank"><?php _e('Click Here', 'wpcaptchadomain'); ?></a>.
				   </p>
				</td>
			 </tr>
			<tr height="40">
                <td><?php _e('Public Key', 'wpcaptchadomain'); ?>: </td>
                <td>
                    <input type="text" value="<?php echo $public_key; ?>" id="publickey" name="publickey" size="50" />
                </td>
            </tr>
			<tr height="40">
                <td><?php _e('Private Key', 'wpcaptchadomain'); ?>: </td>
                <td>
                    <input type="text" value="<?php echo $private_key; ?>" id="privatekey" name="privatekey" size="50" />
                </td>
            </tr>			
    </table>
    <h3><?php echo 'Enable reCaptcha for';?></h3>
    <table>
            <tr height="40">
                    <td><?php _e("Login form", "wpcaptchadomain");?>: </td>
                    <td>
						<input type="checkbox" <?php echo $c_login_yes;?> name="captcha_login" value="yes" />
                    </td>
            </tr>
            <tr height="40">
                    <td><?php _e('Register form', 'wpcaptchadomain');?>: </td>
                    <td>
						<input type="checkbox" <?php echo $c_register_yes;?> name="captcha_register" value="yes" />
                    </td>
            </tr>
            <tr height="40">
                    <td><?php _e('Lost Password form', 'wpcaptchadomain');?>: </td>
                    <td>
						<input type="checkbox" <?php echo $c_lost_yes;?> name="captcha_lost" value="yes" />
                    </td>
            </tr>
            <tr height="40">
                    <td><?php _e('Comments form', 'wpcaptchadomain');?>: </td>
                    <td>
						<input type="checkbox" <?php echo $c_comments_yes;?> name="captcha_comments" value="yes" />
                    </td>
            </tr>
            <tr height="60">
                <td>				
				<input class='button-primary' type='submit' name='save_captcha_options' value='<?php _e('Save Changes', 'wpcaptchadomain'); ?>' id='submitbutton' /></td>
                <td></td>
            </tr>
	</table>
	
	</form>
	</div>
</div>