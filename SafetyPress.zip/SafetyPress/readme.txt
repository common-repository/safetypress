=== SafetyPress ===
Contributors: pingcp30
Donate link: http://www.safetypressplugin.com
Tags: hacker,security plugin,
Requires at least: 2.7
Tested up to: 3.4
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Secure your Wordpress blog with many of features.(Please dont forget to give Ratings to Plugin.)

== Description ==

* Remove Wordpress version.
* Remove readme.html
* Remove update noticed for non-admin.
* Remove error noticed when login failed.
* Change your admin page.
* Add your own user with HTTP authentication.
* Change content directory.
* Change database table prefix.
* Backup database and files to Dropbox.
* Limit of login.
* Captcha by reCaptcha.

== Installation ==

1. Upload `SafetyPress.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress