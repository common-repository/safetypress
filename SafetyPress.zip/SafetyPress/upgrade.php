<div class="wrap">
	<div id="icon-options-general" class="icon32"></div><h2>Upgrade Version</h2>
<div class="wrap" style="font-family: Verdana;">

<table width="100%" border="0">
<tr>
<td valign="top">
	<div>
	<h3>What do you get in PRO version?</h3>
	<table>
		<tr>
			<td>
			V2.0 <br/>
			- Change Database Table Prefix.<br/>
			- Hide Wordpress version. Other will not know your Wordpress version and hard to access your blogs.<br/>
			- Minor changed.<br/>
			</td>
		</tr>
		<tr>
			<td>
			V1.2 <br/>
			- Disable right click on blogs. Other will not view HTML page source.<br/>
			- Hide Wordpress version. Other will not know your Wordpress version and hard to access your blogs.<br/>
			</td>
		</tr>
		<tr>
			<td>
			V1.1 <br/>
			- Seperate backup. You can choose backup database and/or Wordpress files and folders.<br/>
			- Upload to Dropbox with ZIP.<br/>
			- Change wp-content directory.<br/>
			- Minor bug fixed.<br/>
			</td>
		</tr>

	</table>
	</div>
	<a href="https://www.safetypressplugin.com"><img src="https://s3.amazonaws.com/safetypress/upgrade.jpg" alt="SafetyPress Plugin" border="0" /></a><br/> 
</td>
<td valign="top" style="text-align:right">
<!-- AWeber Web Form Generator 3.0 -->
<style type="text/css">
#af-form-299860695 .af-body .af-textWrap{width:98%;display:block;float:none;}
#af-form-299860695 .af-body .privacyPolicy{color:#000000;font-size:11px;font-family:Trebuchet MS, sans-serif;}
#af-form-299860695 .af-body a{color:#4F4F4F;text-decoration:underline;font-style:normal;font-weight:normal;}
#af-form-299860695 .af-body input.text, #af-form-299860695 .af-body textarea{background-color:#FFFFFF;border-color:#919191;border-width:1px;border-style:solid;color:#000000;text-decoration:none;font-style:normal;font-weight:normal;font-size:12px;font-family:Trebuchet MS, sans-serif;}
#af-form-299860695 .af-body input.text:focus, #af-form-299860695 .af-body textarea:focus{background-color:#FFFAD6;border-color:#000000;border-width:1px;border-style:solid;}
#af-form-299860695 .af-body label.previewLabel{display:block;float:none;text-align:left;width:auto;color:#000000;text-decoration:none;font-style:normal;font-weight:normal;font-size:14px;font-family:Trebuchet MS, sans-serif;}
#af-form-299860695 .af-body{padding-bottom:15px;padding-top:15px;background-repeat:no-repeat;background-position:inherit;background-image:none;color:#000000;font-size:11px;font-family:Trebuchet MS, sans-serif;}
#af-form-299860695 .af-footer{padding-bottom:5px;padding-top:5px;padding-right:10px;padding-left:10px;background-color:#000000;background-repeat:no-repeat;background-position:top left;background-image:none;border-width:1px;border-bottom-style:none;border-left-style:none;border-right-style:none;border-top-style:none;color:#FFFFFF;font-size:12px;font-family:Trebuchet MS, sans-serif;}
#af-form-299860695 .af-header{padding-bottom:1px;padding-top:1px;padding-right:10px;padding-left:60px;background-color:#000000;background-repeat:no-repeat;background-position:inherit;background-image:url("http://forms.aweber.com/images/forms/mail-icon/black/header.png");border-width:1px;border-bottom-style:none;border-left-style:none;border-right-style:none;border-top-style:none;color:#FFFFFF;font-size:14px;font-family:Trebuchet MS, sans-serif;}
#af-form-299860695 .af-quirksMode .bodyText{padding-top:2px;padding-bottom:2px;}
#af-form-299860695 .af-quirksMode{padding-right:10px;padding-left:10px;}
#af-form-299860695 .af-standards .af-element{padding-right:10px;padding-left:10px;}
#af-form-299860695 .bodyText p{margin:1em 0;}
#af-form-299860695 .buttonContainer input.submit{background-color:#c2290e;background-image:url("http://forms.aweber.com/images/forms/mail-icon/black/button.png");color:#FFFFFF;text-decoration:none;font-style:normal;font-weight:normal;font-size:14px;font-family:Verdana, sans-serif;}
#af-form-299860695 .buttonContainer input.submit{width:auto;}
#af-form-299860695 .buttonContainer{text-align:right;}
#af-form-299860695 body,#af-form-299860695 dl,#af-form-299860695 dt,#af-form-299860695 dd,#af-form-299860695 h1,#af-form-299860695 h2,#af-form-299860695 h3,#af-form-299860695 h4,#af-form-299860695 h5,#af-form-299860695 h6,#af-form-299860695 pre,#af-form-299860695 code,#af-form-299860695 fieldset,#af-form-299860695 legend,#af-form-299860695 blockquote,#af-form-299860695 th,#af-form-299860695 td{float:none;color:inherit;position:static;margin:0;padding:0;}
#af-form-299860695 button,#af-form-299860695 input,#af-form-299860695 submit,#af-form-299860695 textarea,#af-form-299860695 select,#af-form-299860695 label,#af-form-299860695 optgroup,#af-form-299860695 option{float:none;position:static;margin:0;}
#af-form-299860695 div{margin:0;}
#af-form-299860695 fieldset{border:0;}
#af-form-299860695 form,#af-form-299860695 textarea,.af-form-wrapper,.af-form-close-button,#af-form-299860695 img{float:none;color:inherit;position:static;background-color:none;border:none;margin:0;padding:0;}
#af-form-299860695 input,#af-form-299860695 button,#af-form-299860695 textarea,#af-form-299860695 select{font-size:100%;}
#af-form-299860695 p{color:inherit;}
#af-form-299860695 select,#af-form-299860695 label,#af-form-299860695 optgroup,#af-form-299860695 option{padding:0;}
#af-form-299860695 table{border-collapse:collapse;border-spacing:0;}
#af-form-299860695 ul,#af-form-299860695 ol{list-style-image:none;list-style-position:outside;list-style-type:disc;padding-left:40px;}
#af-form-299860695,#af-form-299860695 .quirksMode{width:290px;}
#af-form-299860695.af-quirksMode{overflow-x:hidden;}
#af-form-299860695{background-color:#F0F0F0;border-color:#CFCFCF;border-width:1px;border-style:solid;}
#af-form-299860695{display:block;}
#af-form-299860695{overflow:hidden;}
.af-body .af-textWrap{text-align:left;}
.af-body input.image{border:none!important;}
.af-body input.submit,.af-body input.image,.af-form .af-element input.button{float:none!important;}
.af-body input.text{width:100%;float:none;padding:2px!important;}
.af-body.af-standards input.submit{padding:4px 12px;}
.af-clear{clear:both;}
.af-element label{text-align:left;display:block;float:left;}
.af-element{padding:5px 0;}
.af-form-wrapper{text-indent:0;}
.af-form{text-align:left;margin:auto;}
.af-header,.af-footer{margin-bottom:0;margin-top:0;padding:10px;}
.af-quirksMode .af-element{padding-left:0!important;padding-right:0!important;}
.lbl-right .af-element label{text-align:right;}
body {
}
</style>
<form method="post" class="af-form-wrapper" action="http://www.aweber.com/scripts/addlead.pl"  >
<div style="display: none;">
<input type="hidden" name="meta_web_form_id" value="299860695" />
<input type="hidden" name="meta_split_id" value="" />
<input type="hidden" name="listname" value="safetypress-ps" />
<input type="hidden" name="redirect" value="http://www.aweber.com/thankyou-coi.htm?m=text" id="redirect_f6742e4c704c5bfa40b309786439a715" />

<input type="hidden" name="meta_adtracking" value="SafetyPress_Free" />
<input type="hidden" name="meta_message" value="1" />
<input type="hidden" name="meta_required" value="name,email" />

<input type="hidden" name="meta_tooltip" value="" />
</div>
<div id="af-form-299860695" class="af-form"><div id="af-header-299860695" class="af-header"><div class="bodyText"><p style="text-align: center;"><span style="font-size: 18px;"><strong>&nbsp;Subscribe for SafetyPress</strong></span></p></div></div>
<div id="af-body-299860695"  class="af-body af-standards">
<div class="af-element">
<label class="previewLabel" for="awf_field-40897346">Name: </label>
<div class="af-textWrap">
<input id="awf_field-40897346" type="text" name="name" class="text" value=""  tabindex="500" />
</div>
<div class="af-clear"></div></div>
<div class="af-element">
<label class="previewLabel" for="awf_field-40897347">Email: </label>
<div class="af-textWrap"><input class="text" id="awf_field-40897347" type="text" name="email" value="" tabindex="501"  />
</div><div class="af-clear"></div>
</div>
<div class="af-element buttonContainer">
<input name="submit" id="af-submit-image-299860695" type="image" class="image" style="background: none;" alt="Submit Form" src="http://www.aweber.com/images/forms/mail-icon/black/button.png" tabindex="502" />
<div class="af-clear"></div>
</div>
<div class="af-element privacyPolicy" style="text-align: center"><p>We respect your <a title="Privacy Policy" href="http://www.aweber.com/permission.htm" target="_blank">email privacy</a></p>
<div class="af-clear"></div>
</div>
</div>
<div id="af-footer-299860695" class="af-footer"><div class="bodyText"><p style="text-align: left;"><span style="font-size: 11px;">We hate spam like you.</span></p>
<p style="text-align: left;"><span style="font-size: 11px;">We will not share your email information to others.</span></p></div></div>
</div>
<div style="display: none;"><img src="http://forms.aweber.com/form/displays.htm?id=TJycHGwMbJys" alt="" /></div>
</form>
<script type="text/javascript">
    <!--
    (function() {
        var IE = /*@cc_on!@*/false;
        if (!IE) { return; }
        if (document.compatMode && document.compatMode == 'BackCompat') {
            if (document.getElementById("af-form-299860695")) {
                document.getElementById("af-form-299860695").className = 'af-form af-quirksMode';
            }
            if (document.getElementById("af-body-299860695")) {
                document.getElementById("af-body-299860695").className = "af-body inline af-quirksMode";
            }
            if (document.getElementById("af-header-299860695")) {
                document.getElementById("af-header-299860695").className = "af-header af-quirksMode";
            }
            if (document.getElementById("af-footer-299860695")) {
                document.getElementById("af-footer-299860695").className = "af-footer af-quirksMode";
            }
        }
    })();
    -->
</script>

<!-- /AWeber Web Form Generator 3.0 -->
</td>
</tr>
</table>
</div>

</div>