<?php if (! defined('ABSPATH')) exit; ?>
<?php 
	
	if(isset($_POST['Save'])){
		if ( !isset( $_POST['hide_wp_admin'] ) )
		{
			update_option('ld_hide_wp_admin', 'N');
		}
		else
		{
			if ( $_POST['hide_wp_admin'] == 'Y' )
				update_option('ld_hide_wp_admin', 'Y');
			else
				update_option('ld_hide_wp_admin', 'N');
		}
		
		if ( isset( $_POST['login_base'] ) )
		{
			$exp = explode('/', $_POST['login_base'], 2);
			$base = reset( $exp );
			$base = sanitize_title_with_dashes( $base);
			$base = str_replace('/', '', $base);
			$disallowed = array(
				'user', 'wp-admin', 'wp-content', 'wp-includes', 'wp-feed.php', 'index', 'feed', 'rss', 'robots', 'robots.txt', 'wp-login.php','login'
			);
			if ( in_array( $base, $disallowed ) )
			{
				define('LD_DIS_BASE', TRUE);
			}
			else
			{
				$base = trim($base);
				update_option('ld_login_base', $base);
				$login_base = sanitize_title_with_dashes ( $base );
			}
		}
		}
		//	Redirect
		define('LD_WP_ADMIN', TRUE);
		$login_base = get_option('ld_login_base');
?>
<div class="wrap">
	<div id="icon-options-general" class="icon32"></div>
	<h2>Hide Admin</h2>
	<?php if ( defined('LD_WP_ADMIN') && LD_WP_ADMIN == TRUE ) { ?>
	<div class="updated fade">
		<p>Options updated!</p>
	</div>
	<?php } 
if ( defined('LD_DIS_BASE') && LD_DIS_BASE == TRUE )
{
	?>
	<div class="updated fade">
		<p>You can't make that your URL Base! </p>
	</div>
	<?php
}
?>
	
	<form method="POST" action="<?php echo admin_url('admin.php?page=hide-admin'); ?>">
		<?php
		//	Nonces
		wp_nonce_field('safetypress');
		?>
		<h3>Hide Admin</h3>
		<div>
			<input type="checkbox" name="hide_wp_admin" value="Y" <?php if ( get_option('ld_hide_wp_admin') == 'Y' ) { ?> checked <?php } ?>>
			Disable admin page and send to <a href="http://en.wikipedia.org/wiki/HTTP_404">404 error page</a> instead.<br/><br/>
			You will not access
			<ul>
				<li><?php echo admin_url(); ?></li>
				<li><?php echo wp_guess_url().'/admin/'; ?></li>
				<li><?php echo wp_guess_url().'/login/'; ?></li>
				<li><?php echo wp_guess_url().'/wp-login.php'; ?></li>
			</ul>
		</div>		
		<br />
		<?php
			global $auth_obj;
			$url = "";
			if($login_base=="")
				$url = wp_guess_url() . '/login';
			else
				$url = wp_guess_url() . '/'. $login_base;
		?>
		<br/>
		<h3>Your current login URL is <code><a href="<?php echo $url; ?>"><?php echo $url; ?></a></code>.</h3>
		<h3>Change Login URL</h3>		
		<?php echo wp_guess_url().'/'; ?>
			<input type="text" name="login_base" value="<?php echo $login_base; ?>" /><br/> If you leave it <strong>blank</strong>, it will be disabled.<br />
			
		<br/>
		<br/>
		<p>
			<h4>Please Note Something!</h4>
			<p>If you are using a cache plugin (WTC, WP Super Cache, etc), you need to enable it to not cache the above base. That means (for most caching plugins) adding whatever you enter into the box above into your plugins Caching Whitelist, that is the list of URLs that your plugin doesn't cache.</p>
		</p>
		<input type="hidden" name="did_update" value="yes_we_did">
		<input class='button-primary' type='submit' name='Save' value='<?php _e('Save Changes'); ?>' id='submitbutton' />
	</form>
</div>