<div class="wrap">
	<div id="icon-options-general" class="icon32"></div><h2>Login Limit</h2>
<div class="wrap" style="font-family: Verdana;">
<?php
if(isset($_POST['save_login_options'])){
?>
    <div id="message" class="updated fade"><p><strong>Save complete</strong></p></div>
<?php
	if ( !isset( $_POST['checklogin'] ) )
	{
		update_option('checklogin', '');
	}
	else
	{
		if ( $_POST['checklogin'] == 'yes' )
			update_option('checklogin', 'yes');
		else
			update_option('checklogin', 'no');
	}
	if(isset($_POST['allowed_retries']) && is_numeric($_POST['allowed_retries'])) 
		update_option('allowed_retries', $_POST['allowed_retries']);
	if(isset($_POST['lockout_duration']) && is_numeric($_POST['lockout_duration'])) 
		update_option('lockout_duration', $_POST['lockout_duration']*60);
	if(isset($_POST['allowed_lockouts']) && is_numeric($_POST['allowed_lockouts'])) 
		update_option('allowed_lockouts', $_POST['allowed_lockouts']);
	if(isset($_POST['long_duration']) && is_numeric($_POST['long_duration'])) 
		update_option('long_duration', $_POST['long_duration']*3600);
	if(isset($_POST['valid_duration']) && is_numeric($_POST['valid_duration'])) 
		update_option('valid_duration', $_POST['valid_duration']*3600);	
}
	
/*
 * Constants
 */

/* Notify value checked against these in limit_login_sanitize_variables() */
define('LIMIT_LOGIN_LOCKOUT_NOTIFY_ALLOWED', 'log,email');

	?>
	<div class="wrap">
	  
	  
	  <h3>Login Setting</h3>
	  
	  <form action="" method="post">
		<?php wp_nonce_field('limit-login-attempts-options'); ?>		
	    <table class="form-table">
			<tr>
				<td colspan="2"><input type="checkbox" name="checklogin" value="yes" <?php if ( get_option('checklogin') == 'yes' ) { echo 'checked="checked"';} ?> /> Check this to enable Login Limits</td>
			</tr>
		  <tr>
			<th scope="row" valign="top">Number of login attempts per lockout</th>
			<td>
			  <input type="text" size="3" maxlength="4" value="<?php echo get_option('allowed_retries'); ?>" name="allowed_retries" />			  
			</td>
		  </tr>
		   <tr>
			<th scope="row" valign="top">Waiting time when lockout</th>
			<td>			  
			  <input type="text" size="3" maxlength="4" value="<?php echo get_option('lockout_duration')/60; ?>" name="lockout_duration" />minutes
			</td>
		  </tr>
		   <tr>
			<th scope="row" valign="top">Max number of lockout</th>
			<td>			  
			  <input type="text" size="3" maxlength="4" value="<?php echo get_option('allowed_lockouts'); ?>" name="allowed_lockouts" />then increase lockout time to<input type="text" size="3" maxlength="4" value="<?php echo get_option('long_duration')/3600; ?>" name="long_duration" />hours			  
			</td>
		  </tr>
		   <tr>
			<th scope="row" valign="top">Waiting time before reset</th>
			<td>			
			  <input type="text" size="3" maxlength="4" value="<?php echo get_option('valid_duration')/3600; ?>" name="valid_duration" />hours
			</td>
		  </tr>		  
		</table>
		<p class="submit">
			<input class='button-primary' type='submit' name='save_login_options' value='<?php _e('Save Changes'); ?>' id='submitbutton' />
		</p>
	  </form>
	  <?php
		$log = get_option('limit_login_logged');

		if (is_array($log) && count($log) > 0) {
	  ?>
	  <h3><?php echo 'Statistics'; ?></h3>
	  <form action="<?php echo admin_url('admin.php?page=login-limits'); ?>" method="post">
		<?php wp_nonce_field('limit-login-attempts-options'); ?>
	    <table class="form-table">
		  <tr>
			<th scope="row" valign="top"><?php echo __('Total lockouts','limit-login-attempts'); ?></th>
			<td>
			  <?php if ($lockouts_total > 0) { ?>
			  <input name="reset_total" value="<?php echo __('Reset Counter','limit-login-attempts'); ?>" type="submit" />
			  <?php echo sprintf(_n('%d lockout since last reset', '%d lockouts since last reset', $lockouts_total, 'limit-login-attempts'), $lockouts_total); ?>
			  <?php } else { echo __('No lockouts yet','limit-login-attempts'); } ?>
			</td>
		  </tr>
		  <?php if ($lockouts_now > 0) { ?>
		  <tr>
			<th scope="row" valign="top"><?php echo __('Active lockouts','limit-login-attempts'); ?></th>
			<td>
			  <input name="reset_current" value="<?php echo __('Restore Lockouts','limit-login-attempts'); ?>" type="submit" />
			  <?php echo sprintf(__('%d IP is currently blocked from trying to log in','limit-login-attempts'), $lockouts_now); ?> 
			</td>
		  </tr>
		  <?php } ?>
		</table>
	  </form>
	  <h3><?php echo __('Lockout log','limit-login-attempts'); ?></h3>
	  <form action="<?php echo admin_url('admin.php?page=login-limits'); ?>" method="post">
		<?php wp_nonce_field('limit-login-attempts-options'); ?>
		<input type="hidden" value="true" name="clear_log" />
		<p class="submit">
		  <input name="submit" value="<?php echo __('Clear Log','limit-login-attempts'); ?>" type="submit" />
		</p>
	  </form>
	  <style type="text/css" media="screen">
		.limit-login-log th {
			font-weight: bold;
		}
		.limit-login-log td, .limit-login-log th {
			padding: 1px 5px 1px 5px;
		}
		td.limit-login-ip {
			font-family:  "Courier New", Courier, monospace;
			vertical-align: top;
		}
		td.limit-login-max {
			width: 100%;
		}
	  </style>
	  <div class="limit-login-log">
		<table class="form-table">
		  <?php limit_login_show_log($log); ?>
		</table>
	  </div>
	  <?php
		}
	  ?>

	</div>	
	<?php		
//}	
?>