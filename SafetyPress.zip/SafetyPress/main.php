<?php 
/*
Plugin Name: SafetyPress
Plugin URI: http://www.safetypressplugin.com
Description: Secure your wordpress site.
Version: 1.0
Author: Theerapat Apiroop
Author URI: support@safetypressplugin.com
License: GPL
*/
include ('main2.php');
?>