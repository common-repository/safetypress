<div class="wrap">
	<div id="icon-options-general" class="icon32"></div><h2>Change Content Directory</h2>
<div id="message" class="updated fade">
	<p><strong>You must upgrade version to use this feature!</strong></p>
	<a href="<?php echo admin_url('admin.php?page=upgrade'); ?>">Upgrade Here!</a>
</div>
<!--<form method="POST" action="">-->
	<table class="form-table">
		<tr valign="top">
			<th scope="row" class="settinglabel">
				<label for "dirname">Directory Name</label>
			</th>
			<td class="settingfield">
				<?php if ( isset( $_POST['save_wp_content'] ) ) {
					$dirname = $_POST['dirname'];
				} else {
					$dirname = substr( WP_CONTENT_DIR, strrpos( WP_CONTENT_DIR, '/' ) + 1 );
				}?>
				<input id="dirname" name="dirname" type="text" value="<?php echo $dirname;?>" /> <p>For example, wp-content</p>
				<p>Enter a new directory name to replace "wp-content." You may need to log in again after performing this operation.</p>
				<p>Warning! This may break to other plugins or themes which hardcode "wp-content" as directory name. Please use at your own risk!</p>
			</td>
		</tr>
	</table>
	<p class="submit"><input type="submit" class="button-primary" name='save_wp_content' value="Save Changes" /></p>
<!--</form>-->

</div>