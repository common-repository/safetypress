<?php 

//	This file name
define('LD_FILE_NAME', __FILE__ );
define('WP_CAPTCHA_DIR_URL', plugin_dir_url(__FILE__));
define('WP_CAPTCHA_DIR', dirname(__FILE__));
define('LIMIT_LOGIN_DIRECT_ADDR', 'REMOTE_ADDR');
define('LIMIT_LOGIN_PROXY_ADDR', 'HTTP_X_FORWARDED_FOR');
include( dirname( __FILE__ ) . '/Captcha/recaptchalib.php' );
/**
 *	This is the plugin that will add security to our site
 *
 *	@author Theerapat Apiroop <support@safetypressplugin.com>
 *	@version 1.0
**/
class SafetyPress {	

	
	/**
	 * The current user ID from our internal array
	 *
	 * @access private
	**/
	private $current_user = FALSE;
	
	/**
	 * The base to get the login url
	 *
	 * @access private
	**/
	private $login_base = FALSE;
	
	function SafetyPress()
	{
		//	Add the action to setup the menu.
		add_action('admin_menu', array( &$this, 'set_menu'));

		register_deactivation_hook(__FILE__, array( &$this, 'safetypress_deactivate'));
		//	Setup the plugin.
		$this->setup_hide_admin();
		
		//	Hide the login form
		$this->redo_login_form();
		
		//	We no longer update the options here, but rather when we call on the callback function from the menu, more secure.
	}
	
	function safetypress_deactivate() {
       delete_option('safetypress_checkhttp');
	   delete_option('safetypress_username');
	   delete_option('safetypress_password');
	   delete_option('ld_http_auth');
	   delete_option('ld_hide_wp_admin');
	   delete_option('wpcaptcha_status');
	   delete_option('limit_login_lockouts_total');
	   delete_option('limit_login_lockouts');
	   delete_option('limit_login_retries');
	   delete_option('limit_login_retries_valid');
	   delete_option('limit_login_logged');
	   delete_option('checklogin');
	   delete_option('allowed_retries');
	   delete_option('lockout_duration');
	   delete_option('allowed_lockouts');
	   delete_option('long_duration');
	   delete_option('valid_duration');
	   delete_option('safetypress_licensekey');
	   delete_option('safetypress_email');
	   delete_option('safetypress_paymentid');
	   delete_option('recaptcha_publickey');
	   delete_option('recaptcha_privatekey');
	   delete_option('wpcaptcha_login');
	   delete_option('wpcaptcha_register');
	   delete_option('wpcaptcha_lost');
	   delete_option('wpcaptcha_comments');
	   delete_option('dropbox-history');
	   delete_option('dropbox-actions');
	   delete_option('dropbox-options');
	   delete_option('dropbox-processed-files');
	   $timestamp = wp_next_scheduled('execute_periodic_drobox_backup');
		if ($timestamp) {
			wp_unschedule_event($timestamp, 'execute_periodic_drobox_backup');
		}
		wp_clear_scheduled_hook('monitor_dropbox_backup_hook');
		wp_clear_scheduled_hook('run_dropbox_backup_hook');
	

	}
	/**
	 * Get a username and password from the HTTP auth
	 *
	 * @return array|bool
	**/
	function get_http_auth_creds()
	{
		// Since PHP saves the HTTP Password in a bunch of places, we have to be able to test for all of them
		$username = NULL;
    	$password = NULL;
		
		// mod_php
		if (isset($_SERVER['PHP_AUTH_USER'])) 
		{
		    $username = $_SERVER['PHP_AUTH_USER'];
		    $password = $_SERVER['PHP_AUTH_PW'];
		}

		// most other servers
		elseif ($_SERVER['HTTP_AUTHENTICATION'])
		{
			if (strpos(strtolower($_SERVER['HTTP_AUTHENTICATION']),'basic') === 0)
			{
				list($username,$password) = explode(':',base64_decode(substr($_SERVER['HTTP_AUTHENTICATION'], 6)));
			}
		}
		
		// Check them - if they're null a/o empty, they're invalid.
		if ( is_null($username) OR is_null($password) OR empty($username) OR empty($password))
			return FALSE;
		else
			return array('username' => $username, 'password' => $password);
	}
	
	
	/**
	 * Update the options
	 *
	 * @access private
	**/
	function hideadmin()
	{
		if ( !isset( $_GET['page'] ) )
			return;
		
		if ( $_GET['page'] !== 'hide-admin' )
			return;
		//if ( $_GET['page'] !== 'safetypress' )
		//	return;
			
		if ( !isset( $_POST['did_update'] ) )
			return;
		
		//	Nonce
		$nonce = $_POST['_wpnonce'];
		if (! wp_verify_nonce($nonce, 'safetypress') )
			wp_die('Security error, please try again.');
		
		//	---------------------------------------------------
		//	They're updating.
		//	---------------------------------------------------
		if ( isset( $_POST['http_auth'] ) )
			update_option('ld_http_auth', trim( strtolower( $_POST['http_auth'] ) ) );
		else
			update_option('ld_http_auth', 'none' );
		
		if ( !isset( $_POST['hide_wp_admin'] ) )
		{
			update_option('ld_hide_wp_admin', 'N');
		}
		else
		{
			if ( $_POST['hide_wp_admin'] === 'Y' )
				update_option('ld_hide_wp_admin', 'Y');
			else
				update_option('ld_hide_wp_admin', 'N');
		}
		
		if ( isset( $_POST['login_base'] ) )
		{
			$exp = explode('/', $_POST['login_base'], 2);
			$base = reset( $exp );
			$base = sanitize_title_with_dashes( $base);
			$base = str_replace('/', '', $base);
			
			$disallowed = array(
				'user', 'wp-admin', 'wp-content', 'wp-includes', 'wp-feed.php', 'index', 'feed', 'rss', 'robots', 'robots.txt', 'wp-login.php','login'
			);
			if ( in_array( $base, $disallowed ) )
			{
				define('LD_DIS_BASE', TRUE);
			}
			else
			{
				
				update_option('ld_login_base', $base);
				$this->login_base = sanitize_title_with_dashes ( $base );
			}
		}
		
		//	Redirect
		define('LD_WP_ADMIN', TRUE);
		return;
	}
	
	
	/**
	 * Send headers to the browser that are going to ask for a username/pass
	 * from the browser.
	 *
	 * @access private
	 * @return void
	**/
	private function inauth_headers()
	{
		//	Disable if there is a text file there.
		if ( file_exists(dirname(__FILE__).DIRECTORY_SEPARATOR.'disable_auth.txt'))
			return;
		
		header('WWW-Authenticate: Basic realm="Secure Area"');
		header('HTTP/1.0 401 Unauthorized');
		echo '<h1>Authorization Required.</h1>';
		exit;
	}
	
	/**
	 * Get the users for the private creds
	 *
	 * @access private
	**/
	function get_private_users()
	{
		$add['user'] = get_option('safetypress_username');
		$add['pass'] = get_option('safetypress_password');
				
		$opt[] = $add;
		if ( !is_array( $opt ) )
			return array();
		
		return $opt;
	}
	
	/**
	 * Setup hiding wp-admin
	 *
	 * @access void
	**/
	function setup_hide_admin()
	{
		$opt = get_option('safetypress_checkhttp');
		
		//	N, they didn't enable it.
		if ( $opt != 'yes' )
		{
			//setup_http_area();
			return;
		}
		
		//	We're gonna hide it.
		$no_check_files = array('async-upload.php', 'admin-ajax.php', 'wp-app.php');
		$no_check_files = apply_filters('no_check_files', $no_check_files);
		
		$explode = explode('/', $_SERVER['SCRIPT_FILENAME'] );
		$file = end( $explode );
    	if ( in_array( $file, $no_check_files ) )
    	{
			define('INTERNAL_AUTH_PASSED', TRUE);
			return;
		}
    	
		//	We only will hide it if we are in admin (/wp-admin/)
		if ( is_admin() )
		{	
			$this->setup_http_area();	
		}
	}
	
	/**
	 * Setting up the HTTP Auth
	 *
	 * Here, we only check if it's enabled
	 *
	 * @access private
	**/
	function setup_http_area()
	{
		$users = $this->get_private_users();
		
		// We want a user to exist.
		// If nobody is found, we won't lock them out!
		if ( ! $users || ! is_array( $users ) )
			return;
		
		//	Let's NOT lock everybody out
		if ( count( $users ) < 1 )
			return;
		
		// Get the HTTP auth creds
		$creds = $this->get_http_auth_creds();
		
		// Invalid creds
		if (! $creds )
			$this->inauth_headers();
		
		//	Did they enter a valid user?
		if ( $this->user_array_check( $users, $creds['username'], $creds['password'] ) )
		{
			//	Yes!!
			define('INTERNAL_AUTH_PASSED', TRUE);
			$this->set_current_user( $users, $creds['username'] );
			return;
		}
		else
		{
			//	N
			$this->inauth_headers();
			return;
		}			
	}
	/**
	 * Check an internal array of users against a passed user and pass
	 *
	 * @access public
	 * @return bool
	 *
	 * @param array $array The array of users
	 * @param string $user The username to check for
	 * @param string $pass The password to check for (plain text)
	**/
	public function user_array_check( $array, $user, $pass )
	{
		foreach( $array as $key => $val )
		{
			if ( $val['user'] === $user && md5( $pass ) === $val['pass'] )
				return TRUE;
		}
		
		return FALSE;
	}
	
	/**
	 * Set the current user
	 *
	 * @access private
	**/
	private function set_current_user( $array, $user )
	{
		foreach( $array as $key => $val )
		{
			if ( $val['user'] === $user )
				$this->current_user = $key;
		}
	}
	
	/**
	 * Adds the admin menu
	 *
	 * @acces private
	**/
	function set_menu()
	{
		add_menu_page('SafetyPress', 'SafetyPress', 'manage_options', 'safetypress', null );
		add_submenu_page( 'safetypress', '', '', 'manage_options', 'safetypress',  null);
		add_submenu_page( 'safetypress', 'Hide Admin', 'Hide Admin', 'manage_options', 'hide-admin',  array( &$this, 'hide_admin_callback'));
		add_submenu_page( 'safetypress', 'HTTP Authentication', 'HTTP Authentication', 'manage_options', 'private-users',  array( &$this, 'private_user_callback'));		
		add_submenu_page( 'safetypress', 'Login Limits', 'Login Limits', 'manage_options', 'login-limits',  array( &$this, 'limit_login_callback'));
		add_submenu_page( 'safetypress', 'Captcha Setting', 'Captcha Setting', 'manage_options', 'captcha',  array( &$this, 'captcha_callback'));	
		add_submenu_page( 'safetypress', 'Change Content Directory', 'Change Content Directory', 'manage_options', 'change-wp-content',  array( &$this, 'wp_content_callback'));
		add_submenu_page( 'safetypress', 'Backup to Dropbox', 'Backup to Dropbox', 'manage_options', 'backup-to-dropbox',  array( &$this, 'db_dropbox_callback'));		
		add_submenu_page( 'safetypress', 'Upgrade Version', 'Upgrade Version', 'manage_options', 'upgrade',  array( &$this, 'upgrade_callback'));		
	}
	/**
	 * The callback for the admin area
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function setoption_callback()
	{
		require_once( dirname( __FILE__ ) . '/getkey.php' );
	}
	/**
	 * The callback for the admin area
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function hide_admin_callback()
	{
		//	Update the options
		$this->hideadmin();		
		require_once( dirname( __FILE__ ) . '/hideadmin.php' );
	}	
	
	/**
	 * The callback for the admin area
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function upgrade_callback()
	{	
		require_once( dirname( __FILE__ ) . '/upgrade.php' );
	}	
	/**
	 * The callback for ther private users management.
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function private_user_callback()
	{		
		require_once( dirname( __FILE__ ) . '/http-authen-users.php' );
	}
	
	/**
	 * The callback for ther private users management.
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function wp_content_callback()
	{
		require_once( dirname( __FILE__ ) . '/wpcontent.php' );
	}
	
	/**
	 * The callback for ther private users management.
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function db_dropbox_callback()
	{
		define('MEMORY_LIMIT', 150);
		define('ERROR_TIMEOUT', 5); //seconds
		define('EXTENSIONS_DIR', implode(array(WP_CONTENT_DIR, 'plugins','SafetyPress', 'Extensions'), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR);		
		require_once( dirname( __FILE__ ) . '/Backup/backup.php' );
	}
	
	/**
	 * The callback for ther private users management.
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function limit_login_callback()
	{		
		require_once( dirname( __FILE__ ) . '/limitlogin.php' );
	}
	
	/**
	 * The callback for ther private users management.
	 *
	 * You need the 'manage_options' capability to get here.
	**/
	function captcha_callback()
	{		
		
		require_once( dirname( __FILE__ ) . '/captchasetting.php' );
	}
	
	/**
	 * Rename the login URL
	 *
	 * @access public
	**/
	public function redo_login_form()
	{	
		
		$login_base = get_option('ld_login_base');
		
		//	It's not enabled.
		if ( $login_base == NULL || !$login_base || $login_base == '' )
			return;
		
		$this->login_base = $login_base;
		unset( $login_base );
		
		//	Setup the filters for the new login form
		add_filter('wp_redirect', array( &$this, 'filter_wp_login'));
		add_filter('network_site_url', array( &$this, 'filter_wp_login'));
		add_filter('site_url', array( &$this, 'filter_wp_login'));
		
		//	We need to get the URL
		//	This means we need to take the current URL,
		//	strip it of an WordPress path (if the blog is located @ /blog/)
		//	And then remove the query string
		//	We also need to remove the index.php from the URL if it exists
		
		//	The blog's URL
		$blog_url = trailingslashit( get_bloginfo('url') );
		
		//	The Current URL
		$schema = is_ssl() ? 'https://' : 'http://';
		$current_url = $schema . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		
		$request_url = str_replace( $blog_url, '', $current_url );
		$request_url = str_replace('index.php/', '', $request_url);
		
		list( $base, $query ) = explode( '?', $request_url, 2 );
		
		//	Remove trailing slash
		$base = rtrim($base,"/");
		$exp = explode( '/', $base, 2 );
		$super_base = reset( $exp );

		if (! is_user_logged_in() ) {
			if ( get_option('ld_hide_wp_admin') == 'Y' && ( $super_base == 'wp-login.php' ||  $super_base == 'login' || $super_base == 'wp-admin' ||  $super_base == 'admin'))
			{
				status_header(404);
				require( get_404_template() );
				
				exit;
			}
		}
		//	Is this the "login" url?
		if ( $base !== $this->login_base )
			return FALSE;
		else
		{
			//	We dont' want a WP plugin caching this page
			@define('NO_CACHE', TRUE);
			@define('WTC_IN_MINIFY', TRUE);
			@define('WP_CACHE', FALSE);
			
			include ABSPATH . "/wp-login.php";
			exit;
		}
	}
	
	/**
	 * Filters out wp-login to whatever they named it
	 *
	 * @access public
	**/
	public function filter_wp_login( $str )
	{
		return str_replace('wp-login.php', $this->login_base, $str);
	}
}

/**
 * The function called at 'init'.
 *
 * Sets up the object
 *
 * @return void
 * @access private
 * @since 1.0
 * @see do_action() Called by the 'init' action.
**/
function ld_setup_auth()
{
	//	Setup the object.
	$auth_obj = new SafetyPress();
}

add_action('init', 'ld_setup_auth');

add_action('init', 'wp_captcha_init_sessions');

/* Hook to store the plugin status */
register_activation_hook(__FILE__, 'wp_captcha_enabled');
register_deactivation_hook(__FILE__, 'wp_captcha_disabled');

function wp_captcha_enabled(){
	update_option('wpcaptcha_status', 'enabled');
}
function wp_captcha_disabled(){
	update_option('wpcaptcha_status', 'disabled');
}

function wp_captcha_init_sessions(){
	if(!session_id()){
		session_start();
	}
	$_SESSION['captcha_type'] = get_option('wpcaptcha_type');
	$_SESSION['captcha_letters'] = get_option('wpcaptcha_letters');
	$_SESSION['total_no_of_characters'] = get_option('wpcaptcha_total_no_of_characters');
	if(empty($_SESSION['total_no_of_characters'])){
		$_SESSION['total_no_of_characters'] = 6;
	}
}

/* Captcha for login authentication starts here */ 
$public_key = get_option('recaptcha_publickey');
$private_key = get_option('recaptcha_privatekey');

$login_captcha = get_option('wpcaptcha_login');

if($login_captcha == 'yes' && $public_key!=""&&$private_key!=""){
	add_action('login_form', 'recaptcha_display');
	add_action( 'login_enqueue_scripts', 'my_login_stylesheet' );
	add_filter( 'login_redirect', 'recaptcha_login_redirect', 10, 3 );	
}

function my_login_stylesheet() {
	echo '<style> .login form{margin-left:-25px;padding-left:20px;padding-right:20px;}</style>';
}


function recaptcha_display(){
	$publickey = get_option('recaptcha_publickey');
	echo recaptcha_get_html($publickey,false,is_ssl());
}

function recaptcha_login_redirect(){
	$privatekey = get_option('recaptcha_privatekey');
	$response = recaptcha_check_answer($privatekey, $_SERVER['REMOTE_ADDR'], $_POST['recaptcha_challenge_field'], $_POST['recaptcha_response_field']);

	// response is bad, add incorrect response error
	if (!$response->is_valid)
		if ($response->error == 'incorrect-captcha-sol'){
			$_SESSION['captcha_error'] = __('Incorrect captcha confirmation!', 'wpcaptchadomain');
			wp_die('Error: You entered in the wrong CAPTCHA phrase. Press your browser\'s back button and try again.');
		}
	/* Captcha match: take to the admin panel */
			
	return home_url('/wp-admin/');	
	
}

/* <!-- Captcha for login authentication ends here --> */

/* Captcha for Comments ends here */
$comment_captcha = get_option('wpcaptcha_comments');
if($comment_captcha == 'yes' && $public_key!=""&&$private_key!=""){
	global $wp_version;
	if( version_compare($wp_version,'3','>=') ) { // wp 3.0 +
		add_action( 'comment_form_after_fields', 'recaptcha_display', 1 );
		add_action( 'comment_form_logged_in_after', 'recaptcha_display', 1 );
	}	
	// for WP before WP 3.0
	add_action( 'comment_form', 'recaptcha_display' );	
	add_filter( 'preprocess_comment', 'include_captcha_comment_post',1 );
}

// this function checks captcha posted with the comment
function include_captcha_comment_post($comment) {	
	$privatekey = get_option('recaptcha_privatekey');
	$response = recaptcha_check_answer($privatekey, $_SERVER['REMOTE_ADDR'], $_POST['recaptcha_challenge_field'], $_POST['recaptcha_response_field']);

	// response is bad, add incorrect response error
	if (!$response->is_valid){ 
		
		if ($response->error == 'incorrect-captcha-sol'){
			wp_die('Error: You entered in the wrong CAPTCHA phrase. Press your browser\'s back button and try again.');
		}
	}
   return $comment;
} 

/* <!-- Captcha for Comments authentication ends here --> */

// Add captcha in the register form
$register_captcha = get_option('wpcaptcha_register');
if($register_captcha == 'yes' && $public_key!=""&&$private_key!=""){
	add_action('register_form', 'recaptcha_display');
	add_action( 'register_post', 'include_captcha_register_post', 10, 3 );
}

/* This function checks captcha posted with registration */
function include_captcha_register_post($errors) {
	$privatekey = get_option('recaptcha_privatekey');
	$response = recaptcha_check_answer($privatekey, $_SERVER['REMOTE_ADDR'], $_REQUEST['recaptcha_challenge_field'], $_REQUEST['recaptcha_response_field']);

	// response is bad, add incorrect response error
	if (!$response->is_valid){
		if ($response->error == 'incorrect-captcha-sol'){
			wp_die('Error: You entered in the wrong CAPTCHA phrase. Press your browser\'s back button and try again.');
		}
	}
   return($errors);
} 
/* End of the function include_captcha_register_post */

$lost_captcha = get_option('wpcaptcha_lost');
// Add captcha into lost password form
if($lost_captcha == 'yes' && $public_key!=""&&$private_key!=""){
	add_action( 'lostpassword_form', 'recaptcha_display' );
	add_action( 'lostpassword_post', 'include_wp_captcha_lostpassword_post', 10, 3 );
}

function include_wp_captcha_lostpassword_post() {

	$privatekey = get_option('recaptcha_privatekey');
	$response = recaptcha_check_answer($privatekey, $_SERVER['REMOTE_ADDR'], $_POST['recaptcha_challenge_field'], $_POST['recaptcha_response_field']);

	// response is bad, add incorrect response error
	if (!$response->is_valid){ 
		
		if ($response->error == 'incorrect-captcha-sol'){
			wp_die('Error: You entered in the wrong CAPTCHA phrase. Press your browser\'s back button and try again.');
		}
	}
   return;

} // function cptch_lostpassword_post

/* Code is poetry. */
limit_to_login_actions();
/* Get options and setup filters & actions */
function limit_to_login_actions() {
	if(get_option('checklogin')=="yes"){
		/* Filters and actions */
		add_action('wp_login_failed', 'try_login_failed');
		add_filter('wp_authenticate_user', 'login_for_authen_user', 99999, 2);
		add_filter('shake_error_codes', 'over_limit_shake_error');
		add_action('login_head', 'limit_login_error_message');
		add_action('login_errors', 'login_fixup_error');
		
		/*
		 * This action should really be changed to the 'authenticate' filter as
		 * it will probably be deprecated. That is however only available in
		 * later versions of WP.
		 */
		add_action('wp_authenticate', 'limit_login_track_credentials', 10, 2);
	}
}
function try_login_failed($username) {
	$ip = limit_login_get_address();

	/* if currently locked-out, do not add to retries */
	$lockouts = get_option('limit_login_lockouts');
	if (!is_array($lockouts)) {
		$lockouts = array();
	}
	if(isset($lockouts[$ip]) && time() < $lockouts[$ip]) {
		return;
	}

	/* Get the arrays with retries and retries-valid information */
	$retries = get_option('limit_login_retries');
	$valid = get_option('limit_login_retries_valid');
	if (!is_array($retries)) {
		$retries = array();
		add_option('limit_login_retries', $retries, '', 'no');
	}
	if (!is_array($valid)) {
		$valid = array();
		add_option('limit_login_retries_valid', $valid, '', 'no');
	}

	/* Check validity and add one to retries */
	if (isset($retries[$ip]) && isset($valid[$ip]) && time() < $valid[$ip]) {
		$retries[$ip] ++;
	} else {
		$retries[$ip] = 1;
	}
	$valid[$ip] = time() + get_option('valid_duration');

	/* lockout? */
	if($retries[$ip] % get_option('allowed_retries') != 0) {
		/* 
		 * Not lockout (yet!)
		 * Do housecleaning (which also saves retry/valid values).
		 */
		limit_login_cleanup($retries, null, $valid);
		return;
	}

	/* lockout! */

	$whitelisted = is_limit_login_ip_whitelisted($ip);

	$retries_long = get_option('allowed_retries') * get_option('allowed_lockouts');

	/* 
	 * Note that retries and statistics are still counted and notifications
	 * done as usual for whitelisted ips , but no lockout is done.
	 */
	if ($whitelisted) {
		if ($retries[$ip] >= $retries_long) {
			unset($retries[$ip]);
			unset($valid[$ip]);
		}
	} else {
		global $limit_login_just_lockedout;
		$limit_login_just_lockedout = true;

		/* setup lockout, reset retries as needed */
		if ($retries[$ip] >= $retries_long) {
			/* long lockout */
			$lockouts[$ip] = time() + get_option('long_duration');
			unset($retries[$ip]);
			unset($valid[$ip]);
		} else {
			/* normal lockout */
			$lockouts[$ip] = time() + get_option('lockout_duration');
		}
	}

	/* do housecleaning and save values */
	limit_login_cleanup($retries, $lockouts, $valid);

	/* do any notification */
	limit_login_notify($username);

	/* increase statistics */
	$total = get_option('limit_login_lockouts_total');
	if ($total === false || !is_numeric($total)) {
		add_option('limit_login_lockouts_total', 1, '', 'no');
	} else {
		update_option('limit_login_lockouts_total', $total + 1);
	}
}

/* Keep track of if user or password are empty, to filter errors correctly */
function limit_login_track_credentials($user, $password) {
	global $limit_login_nonempty_credentials;

	$limit_login_nonempty_credentials = (!empty($user) && !empty($password));
}

/* Filter: allow login attempt? (called from wp_authenticate()) */
function login_for_authen_user($user, $password) {
	if (is_wp_error($user) || is_limit_login_ok() ) {
		return $user;
	}

	global $limit_login_my_error_shown;
	$limit_login_my_error_shown = true;

	$error = new WP_Error();
	// This error should be the same as in "shake it" filter below
	$error->add('too_many_retries', limit_login_error_msg());
	return $error;
}
/* Filter: add this failure to login page "Shake it!" */
function over_limit_shake_error($error_codes) {
	$error_codes[] = 'too_many_retries';
	return $error_codes;
}
/* Get correct remote address */
function limit_login_get_address($type_name = '') {
	$type = $type_name;
	if (empty($type)) {
		$type = get_option('client_type');
	}

	if (isset($_SERVER[$type])) {
		return $_SERVER[$type];
	}

	/*
	 * Not found. Did we get proxy type from option?
	 * If so, try to fall back to direct address.
	 */
	if ( empty($type_name) && $type == LIMIT_LOGIN_PROXY_ADDR
		 && isset($_SERVER[LIMIT_LOGIN_DIRECT_ADDR])) {

		/*
		 * NOTE: Even though we fall back to direct address -- meaning you
		 * can get a mostly working plugin when set to PROXY mode while in
		 * fact directly connected to Internet it is not safe!
		 *
		 * Client can itself send HTTP_X_FORWARDED_FOR header fooling us
		 * regarding which IP should be banned.
		 */

		return $_SERVER[LIMIT_LOGIN_DIRECT_ADDR];
	}
	
	return '';
}

/* Check if it is ok to login */
function is_limit_login_ok() {
	$ip = limit_login_get_address();

	/* Check external whitelist filter */
	if (is_limit_login_ip_whitelisted($ip)) {
		return true;
	}

	/* lockout active? */
	$lockouts = get_option('limit_login_lockouts');
	return (!is_array($lockouts) || !isset($lockouts[$ip]) || time() >= $lockouts[$ip]);
}
function is_limit_login_ip_whitelisted($ip = null) {
	if (is_null($ip)) {
		$ip = limit_login_get_address();
	}
	$whitelisted = apply_filters('limit_login_whitelist_ip', false, $ip);

	return ($whitelisted === true);
}
/* Fix up the error message before showing it */
function login_fixup_error($content) {
	global $limit_login_just_lockedout, $limit_login_nonempty_credentials, $limit_login_my_error_shown;

	if (!should_limit_login_show_msg()) {
		return $content;
	}

	/*
	 * During lockout we do not want to show any other error messages (like
	 * unknown user or empty password).
	 */
	if (!is_limit_login_ok() && !$limit_login_just_lockedout) {
		return limit_login_error_msg();
	}

	/*
	 * We want to filter the messages 'Invalid username' and
	 * 'Invalid password' as that is an information leak regarding user
	 * account names (prior to WP 2.9?).
	 *
	 * Also, if more than one error message, put an extra <br /> tag between
	 * them.
	 */
	$msgs = explode("<br />\n", $content);

	if (strlen(end($msgs)) == 0) {
		/* remove last entry empty string */
		array_pop($msgs);
	}

	$count = count($msgs);
	$my_warn_count = $limit_login_my_error_shown ? 1 : 0;

	if ($limit_login_nonempty_credentials && $count > $my_warn_count) {
		/* Replace error message, including ours if necessary */
		$content = __('<strong>ERROR</strong>: Incorrect username or password.', 'limit-login-attempts') . "<br />\n";
		if ($limit_login_my_error_shown) {
			$content .= "<br />\n" . limit_login_get_message() . "<br />\n";
		}
		return $content;
	} elseif ($count <= 1) {
		return $content;
	}

	$new = '';
	while ($count-- > 0) {
		$new .= array_shift($msgs) . "<br />\n";
		if ($count > 0) {
			$new .= "<br />\n";
		}
	}

	return $new;
}
/* Add a message to login page when necessary */
function limit_login_error_message() {
	global $error, $limit_login_my_error_shown;

	if (!should_limit_login_show_msg() || $limit_login_my_error_shown) {
		return;
	}

	$msg = limit_login_get_message();

	if ($msg != '') {
		$limit_login_my_error_shown = true;
		$error .= $msg;
	}

	return;
}

/* Return current (error) message to show, if any */
function limit_login_get_message() {
	/* Check external whitelist */
	if (is_limit_login_ip_whitelisted()) {
		return '';
	}

	/* Is lockout in effect? */
	if (!is_limit_login_ok()) {
		return limit_login_error_msg();
	}

	return limit_login_retries_remaining_msg();
}

/* Construct retries remaining message */
function limit_login_retries_remaining_msg() {
	$ip = limit_login_get_address();
	$retries = get_option('limit_login_retries');
	$valid = get_option('limit_login_retries_valid');
	$allowed_retries = get_option('allowed_retries');
	/* Should we show retries remaining? */

	if (!is_array($retries) || !is_array($valid)) {
		/* no retries at all */
		return '';
	}
	if (!isset($retries[$ip]) || !isset($valid[$ip]) || time() > $valid[$ip]) {
		/* no: no valid retries */
		return '';
	}
	if (($retries[$ip] % $allowed_retries) == 0 ) {
		/* no: already been locked out for these retries */
		return '';
	}

	$remaining = max(($allowed_retries - ($retries[$ip] % $allowed_retries)), 0);
	return "<strong>".$remaining."</strong> attempt remaining.";
}

/* Clean up old lockouts and retries, and save supplied arrays */
function limit_login_cleanup($retries = null, $lockouts = null, $valid = null) {
	$now = time();
	$lockouts = !is_null($lockouts) ? $lockouts : get_option('limit_login_lockouts');

	/* remove old lockouts */
	if (is_array($lockouts)) {
		foreach ($lockouts as $ip => $lockout) {
			if ($lockout < $now) {
				unset($lockouts[$ip]);
			}
		}
		update_option('limit_login_lockouts', $lockouts);
	}

	/* remove retries that are no longer valid */
	$valid = !is_null($valid) ? $valid : get_option('limit_login_retries_valid');
	$retries = !is_null($retries) ? $retries : get_option('limit_login_retries');
	if (!is_array($valid) || !is_array($retries)) {
		return;
	}

	foreach ($valid as $ip => $lockout) {
		if ($lockout < $now) {
			unset($valid[$ip]);
			unset($retries[$ip]);
		}
	}

	/* go through retries directly, if for some reason they've gone out of sync */
	foreach ($retries as $ip => $retry) {
		if (!isset($valid[$ip])) {
			unset($retries[$ip]);
		}
	}

	update_option('limit_login_retries', $retries);
	update_option('limit_login_retries_valid', $valid);
}


/* Should we show errors and messages on this page? */
function should_limit_login_show_msg() {
	if (isset($_GET['key'])) {
		/* reset password */
		return false;
	}

	$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

	return ( $action != 'lostpassword' && $action != 'retrievepassword'
			 && $action != 'resetpass' && $action != 'rp'
			 && $action != 'register' );
}

/* Construct informative error message */
function limit_login_error_msg() {
	$ip = limit_login_get_address();
	$lockouts = get_option('limit_login_lockouts');

	$msg = '<strong>ERROR</strong>: Too many login failed.';

	if (!is_array($lockouts) || !isset($lockouts[$ip]) || time() >= $lockouts[$ip]) {
		/* Huh? No timeout active? */
		$msg .=  'Please try again later.';
		return $msg;
	}

	$when = ceil(($lockouts[$ip] - time()) / 60);
	if ($when > 60) {
		$when = ceil($when / 60);
		$msg .= 'You will be locked for '.$when.' hours.';
	} else {
		$msg .= 'You will be locked for '.$when.' minutes.';
	}

	return $msg;
}

/* Email notification of lockout to admin (if configured) */
function limit_login_notify_email($user) {
	$ip = limit_login_get_address();
	$whitelisted = is_limit_login_ip_whitelisted($ip);

	$retries = get_option('limit_login_retries');
	if (!is_array($retries)) {
		$retries = array();
	}

	/* check if we are at the right nr to do notification */
	if ( isset($retries[$ip]) && ( ($retries[$ip] < get_option('allowed_retries')))){
		 //&& ( ($retries[$ip] / get_option('allowed_retries'))
		//	  % get_option('notify_email_after') ) != 0 ) {
		return;
	}

	/* Format message. First current lockout duration */
	if (!isset($retries[$ip])) {
		/* longer lockout */
		$count = get_option('allowed_retries')
			* get_option('allowed_lockouts');
		$lockouts = get_option('allowed_lockouts');
		$time = round(get_option('long_duration') / 3600);
		$when = sprintf(_n('%d hour', '%d hours', $time, 'limit-login-attempts'), $time);
	} else {
		/* normal lockout */
		$count = $retries[$ip];
		$lockouts = floor($count / get_option('allowed_retries'));
		$time = round(get_option('lockout_duration') / 60);
		$when = sprintf(_n('%d minute', '%d minutes', $time, 'limit-login-attempts'), $time);
	}

	$blogname = is_limit_login_multisite() ? get_site_option('site_name') : get_option('blogname');	

	if ($whitelisted) {
		$subject = sprintf(__("[%s] Failed login attempts from whitelisted IP"
				      , 'limit-login-attempts')
				   , $blogname);
	} else {
		$subject = sprintf(__("[%s] Too many failed login attempts"
				      , 'limit-login-attempts')
				   , $blogname);
	}

	$message = sprintf(__("%d failed login attempts (%d lockout(s)) from IP: %s"
			      , 'limit-login-attempts') . "\r\n\r\n"
			   , $count, $lockouts, $ip);
	if ($user != '') {
		$message .= sprintf(__("Last user attempted: %s", 'limit-login-attempts')
				    . "\r\n\r\n" , $user);
	}
	if ($whitelisted) {
		$message .= __("IP was NOT blocked because of external whitelist.", 'limit-login-attempts');
	} else {
		$message .= sprintf(__("IP was blocked for %s", 'limit-login-attempts'), $when);
	}

	$admin_email = is_limit_login_multisite() ? get_site_option('admin_email') : get_option('admin_email');

	@wp_mail($admin_email, $subject, $message);
}
/* Is this WP Multisite? */
function is_limit_login_multisite() {
	return function_exists('get_site_option') && function_exists('is_multisite') && is_multisite();
}


/* Logging of lockout (if configured) */
function limit_login_notify_log($user) {
	$log = $option = get_option('limit_login_logged');
	if (!is_array($log)) {
		$log = array();
	}
	$ip = limit_login_get_address();

	/* can be written much simpler, if you do not mind php warnings */
	if (isset($log[$ip])) {
		if (isset($log[$ip][$user])) {	
			$log[$ip][$user]++;
		} else {
			$log[$ip][$user] = 1;
		}
	} else {
		$log[$ip] = array($user => 1);
	}

	if ($option === false) {
		add_option('limit_login_logged', $log, '', 'no'); /* no autoload */
	} else {
		update_option('limit_login_logged', $log);
	}
}


/* Handle notification in event of lockout */
function limit_login_notify($user) {
	limit_login_notify_email($user);
	limit_login_notify_log($user);
}
set_include_path(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'Backup/PEAR_Includes' . PATH_SEPARATOR . get_include_path());
?>